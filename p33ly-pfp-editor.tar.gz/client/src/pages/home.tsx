import { useState, useRef, useEffect, useCallback } from 'react';
import { flagColours, samplePhotos } from '@/lib/flag-data';
import { CanvasDrawOptions, CutoutType } from '@/lib/types';
import { drawToCanvas, generateFlag, fileToImage, capitalise, download, humanReadableFilesize, getImageSize } from '@/lib/canvas-drawing';

export default function Home() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [selectedFlags, setSelectedFlags] = useState<string[]>(["P33LY in Love"]);
  const [cutoutSize, setCutoutSize] = useState(90);
  const [isGradient, setIsGradient] = useState(false);
  const [resizeInwards, setResizeInwards] = useState(true);
  const [rotating, setRotating] = useState(false);
  const [animationLength, setAnimationLength] = useState(10);
  const [previewCircular, setPreviewCircular] = useState(true);
  const [isRotatingCounterClockwise, setIsRotatingCounterClockwise] = useState(false);

  const [cutoutType, setCutoutType] = useState<CutoutType>(CutoutType.OVERLAY);
  const [overlayRotation, setOverlayRotation] = useState(0);
  const [isRendering, setIsRendering] = useState(false);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [selectedImage, setSelectedImage] = useState<HTMLImageElement | null>(null);
  const [patternImages, setPatternImages] = useState<{[key: string]: HTMLImageElement}>({});
  const [hatImages, setHatImages] = useState<{[key: string]: HTMLImageElement}>({});
  const [selectedHat, setSelectedHat] = useState<string | null>(null);
  const [hatSettings, setHatSettings] = useState({
    scale: 1,
    rotation: 0,
    positionX: 0,
    positionY: -20,
    flipHorizontal: false,
    flipVertical: false
  });

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [isDraggingHat, setIsDraggingHat] = useState(false);
  const [dragStartPos, setDragStartPos] = useState({ x: 0, y: 0 });
  const [initialHatPos, setInitialHatPos] = useState({ x: 0, y: 0 });
  const [showHatControls, setShowHatControls] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [dragHandle, setDragHandle] = useState<string | null>(null);
  const [initialScale, setInitialScale] = useState(1);
  const [initialRotation, setInitialRotation] = useState(0);
  const [hatControlMode, setHatControlMode] = useState<'move' | 'resize' | 'rotate'>('move');
  const [lastTouchTime, setLastTouchTime] = useState(0);

  // Preload pattern and hat images
  useEffect(() => {
    const patternPaths = {
      "P33LY in Love": "/frame1.png",
      "P33LY Peek": "/frame2.png"
    };

    const hatPaths = {
      "P33LY Hat": "/hat1.png",
      "MNFA Cap": "/hat2.png",
      "P33ly Cool Hat": "/hat3.png",
      "P33ly in Love Hat": "/hat4.png"
    };

    const loadAssets = async () => {
      const loadedPatterns: {[key: string]: HTMLImageElement} = {};
      const loadedHats: {[key: string]: HTMLImageElement} = {};
      
      // Load patterns
      for (const [name, path] of Object.entries(patternPaths)) {
        try {
          const img = new Image();
          img.crossOrigin = "anonymous";
          await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            img.src = path;
          });
          loadedPatterns[name] = img;
        } catch (error) {
          console.error(`Failed to load pattern ${name}:`, error);
        }
      }

      // Load hats
      for (const [name, path] of Object.entries(hatPaths)) {
        try {
          const img = new Image();
          img.crossOrigin = "anonymous";
          await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            img.src = path;
          });
          loadedHats[name] = img;
        } catch (error) {
          console.error(`Failed to load hat ${name}:`, error);
        }
      }
      
      setPatternImages(loadedPatterns);
      setHatImages(loadedHats);
    };

    loadAssets();
  }, []);

  // Hat dragging functions
  const getCanvasMousePos = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  }, []);

  const isMouseOverHat = useCallback((mousePos: { x: number; y: number }) => {
    if (!selectedHat || !canvasRef.current) return false;
    
    const canvas = canvasRef.current;
    const hatBaseSize = Math.min(canvas.width, canvas.height) * 0.3;
    const hatWidth = hatBaseSize * hatSettings.scale;
    const hatHeight = hatWidth; // Approximate for hit detection
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const hatX = centerX + (hatSettings.positionX / 100) * canvas.width - hatWidth / 2;
    const hatY = centerY + (hatSettings.positionY / 100) * canvas.height - hatHeight / 2;
    
    return mousePos.x >= hatX && mousePos.x <= hatX + hatWidth &&
           mousePos.y >= hatY && mousePos.y <= hatY + hatHeight;
  }, [selectedHat, hatSettings]);

  const getHatHandles = useCallback(() => {
    if (!selectedHat || !canvasRef.current) return [];
    
    const canvas = canvasRef.current;
    const hatBaseSize = Math.min(canvas.width, canvas.height) * 0.3;
    const hatWidth = hatBaseSize * hatSettings.scale;
    const hatHeight = hatWidth;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const hatX = centerX + (hatSettings.positionX / 100) * canvas.width;
    const hatY = centerY + (hatSettings.positionY / 100) * canvas.height;
    
    // Dynamic inset that scales with hat size
    const insetRatio = 0.15; // 15% inset from hat edges (scales with hat size)
    const dynamicInset = Math.max(12, Math.min(hatWidth, hatHeight) * insetRatio);
    
    // Three circular control buttons matching the canvas drawing exactly
    return [
      { id: 'move', x: hatX - hatWidth/2 + dynamicInset, y: hatY - hatHeight/2 + dynamicInset, type: 'move' },
      { id: 'resize', x: hatX + hatWidth/2 - dynamicInset, y: hatY - hatHeight/2 + dynamicInset, type: 'resize' },
      { id: 'rotate', x: hatX, y: hatY + hatHeight/2 - dynamicInset, type: 'rotate' }
    ];
  }, [selectedHat, hatSettings]);

  const getHandleAtPos = useCallback((mousePos: { x: number; y: number }) => {
    const handles = getHatHandles();
    // Much larger touch area for mobile - easier to tap
    const touchRadius = window.innerWidth < 768 ? 30 : 15;
    
    for (const handle of handles) {
      // Check if mouse/touch is within button area
      const distance = Math.sqrt((mousePos.x - handle.x) ** 2 + (mousePos.y - handle.y) ** 2);
      if (distance <= touchRadius) {
        return handle;
      }
    }
    return null;
  }, [getHatHandles]);

  const handleCanvasMouseDown = useCallback((e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!selectedHat) return;
    
    // Handle both mouse and touch events with mobile optimization
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    const mousePos = {
      x: (clientX - rect.left) * (400 / rect.width),
      y: (clientY - rect.top) * (400 / rect.height)
    };
    
    // Check if clicking on control buttons first
    const clickedHandle = getHandleAtPos(mousePos);
    if (clickedHandle) {
      setDragHandle(clickedHandle.type);
      setIsDraggingHat(true);
      setDragStartPos(mousePos);
      setInitialScale(hatSettings.scale);
      setInitialRotation(hatSettings.rotation);
      setInitialHatPos({ x: hatSettings.positionX, y: hatSettings.positionY });
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    
    // If clicking on hat but not on control buttons, use selected mode
    if (isMouseOverHat(mousePos)) {
      setDragHandle(hatControlMode);
      setIsDraggingHat(true);
      setDragStartPos(mousePos);
      setInitialScale(hatSettings.scale);
      setInitialRotation(hatSettings.rotation);
      setInitialHatPos({ x: hatSettings.positionX, y: hatSettings.positionY });
      e.preventDefault();
      e.stopPropagation();
    }
  }, [selectedHat, isMouseOverHat, getHandleAtPos, hatSettings, hatControlMode]);

  const handleCanvasMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    // Enhanced throttling for ultra-smooth performance
    const isMobile = window.innerWidth < 768;
    const now = Date.now();
    if (isMobile && now - lastTouchTime < 8) return; // 120fps throttling for extra smoothness
    if (isMobile) setLastTouchTime(now);
    
    // Handle both mouse and touch events
    const clientX = 'touches' in e ? e.touches[0]?.clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY : e.clientY;
    
    if (!clientX || !clientY) return;
    
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    const mousePos = {
      x: (clientX - rect.left) * (400 / rect.width),
      y: (clientY - rect.top) * (400 / rect.height)
    };
    
    // Keep controls visible when hat is selected (fixes PC visibility issue)
    if (selectedHat) {
      setShowHatControls(true);
    }
    
    if (!isDraggingHat || !canvasRef.current || !dragHandle) return;
    
    const canvas = canvasRef.current;
    const deltaX = mousePos.x - dragStartPos.x;
    const deltaY = mousePos.y - dragStartPos.y;
    

    
    if (dragHandle === 'move' || dragHandle === 'ml' || dragHandle === 'mr') {
      // Move hat position - enhanced smoothness with momentum
      const isMobile = window.innerWidth < 768;
      const sensitivity = isMobile ? 25 : 70; // Further optimized sensitivity
      const smoothing = isMobile ? 0.8 : 0.9; // Momentum smoothing factor
      
      const targetX = initialHatPos.x + (deltaX / canvas.width) * sensitivity;
      const targetY = initialHatPos.y + (deltaY / canvas.height) * sensitivity;
      
      // Apply momentum smoothing for fluid movement
      const currentX = hatSettings.positionX;
      const currentY = hatSettings.positionY;
      const newPosX = currentX + (targetX - currentX) * smoothing;
      const newPosY = currentY + (targetY - currentY) * smoothing;
      
      setHatSettings(prev => ({
        ...prev,
        positionX: Math.max(-50, Math.min(50, newPosX)),
        positionY: Math.max(-50, Math.min(50, newPosY))
      }));
    } else if (dragHandle === 'resize') {
      // Resize hat - mobile optimized with distance-based scaling
      const canvas = canvasRef.current;
      const isMobile = window.innerWidth < 768;
      const centerX = canvas.width / 2 + (initialHatPos.x / 100) * canvas.width;
      const centerY = canvas.height / 2 + (initialHatPos.y / 100) * canvas.height;
      
      // Get resize button position (top-right of hat) - using dynamic inset
      const hatBaseSize = Math.min(canvas.width, canvas.height) * 0.3;
      const hatWidth = hatBaseSize * initialScale;
      const hatHeight = hatWidth; // Assuming square hat for simplicity
      const insetRatio = 0.15;
      const dynamicInset = Math.max(12, Math.min(hatWidth, hatHeight) * insetRatio);
      const resizeButtonX = centerX + hatWidth/2 - dynamicInset;
      const resizeButtonY = centerY - hatWidth/2 + dynamicInset;
      
      // Calculate current distance from resize button to center
      const currentDistance = Math.sqrt((mousePos.x - centerX) ** 2 + (mousePos.y - centerY) ** 2);
      const initialDistance = Math.sqrt((resizeButtonX - centerX) ** 2 + (resizeButtonY - centerY) ** 2);
      
      // Scale based on distance change - enhanced smoothness with easing
      const distanceRatio = currentDistance / initialDistance;
      const dampening = isMobile ? 0.3 : 0.8; // Ultra-smooth dampening for mobile
      
      // Apply easing curve for natural scaling feeling
      const easedRatio = 1 + (distanceRatio - 1) * dampening;
      const smoothing = isMobile ? 0.7 : 0.85; // Momentum smoothing
      const newScale = Math.max(0.2, Math.min(10, initialScale * (1 + (distanceRatio - 1) * dampening)));
      
      setHatSettings(prev => ({
        ...prev,
        scale: newScale
      }));
    } else if (dragHandle === 'rotate') {
      // Rotate hat around its center - ultra-smooth with momentum
      const isMobile = window.innerWidth < 768;
      const centerX = canvas.width / 2 + (initialHatPos.x / 100) * canvas.width;
      const centerY = canvas.height / 2 + (initialHatPos.y / 100) * canvas.height;
      
      const currentAngle = Math.atan2(mousePos.y - centerY, mousePos.x - centerX) * (180 / Math.PI);
      const startAngle = Math.atan2(dragStartPos.y - centerY, dragStartPos.x - centerX) * (180 / Math.PI);
      let angleDelta = currentAngle - startAngle;
      
      // Handle angle wrapping for smooth rotation
      if (angleDelta > 180) angleDelta -= 360;
      if (angleDelta < -180) angleDelta += 360;
      
      // Apply dampening and momentum for ultra-smooth rotation
      const dampening = isMobile ? 0.6 : 0.8; // Smooth rotation sensitivity
      const smoothing = isMobile ? 0.75 : 0.9; // Momentum smoothing
      
      const targetRotation = initialRotation + angleDelta * dampening;
      const currentRotation = hatSettings.rotation;
      let newRotation = currentRotation + (targetRotation - currentRotation) * smoothing;
      
      while (newRotation > 180) newRotation -= 360;
      while (newRotation < -180) newRotation += 360;
      
      setHatSettings(prev => ({
        ...prev,
        rotation: newRotation
      }));
    }
  }, [isDraggingHat, getCanvasMousePos, dragStartPos, initialHatPos, selectedHat, isMouseOverHat, getHandleAtPos, dragHandle, hatSettings, initialScale, initialRotation]);

  const handleCanvasMouseUp = useCallback(() => {
    setIsDraggingHat(false);
    setDragHandle(null);
  }, []);

  const handleCanvasMouseLeave = useCallback(() => {
    setIsDraggingHat(false);
    setDragHandle(null);
    setShowHatControls(false);
  }, []);

  const handleOutsideClick = useCallback((e: React.MouseEvent) => {
    // Hide controls when clicking outside the canvas
    if (e.target !== canvasRef.current) {
      setShowHatControls(false);
    }
  }, []);



  const handleFileSelect = useCallback(async (files: File[]) => {
    if (files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        setSelectedFiles([file]);
        try {
          const img = await fileToImage(file);
          setSelectedImage(img);
        } catch (error) {
          console.error('Failed to load image:', error);
        }
      }
    }
  }, []);

  const handleSamplePhotoClick = useCallback(async (url: string) => {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        setSelectedImage(img);
        setSelectedFiles([]);
      };
      img.onerror = () => {
        console.error('Failed to load sample image');
      };
      img.src = url;
    } catch (error) {
      console.error('Failed to load sample image:', error);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.items.length > 0 && 
        Array.from(e.dataTransfer.items).every(item => item.type.includes("image/"))) {
      setIsDraggingOver(true);
      e.dataTransfer.dropEffect = "copy";
    } else {
      e.dataTransfer.dropEffect = "none";
    }
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFileSelect(files);
  }, [handleFileSelect]);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(Array.from(files));
    }
  }, [handleFileSelect]);

  const addFlag = () => {
    setSelectedFlags([...selectedFlags, "P33ly Frame 1"]);
  };

  const removeFlag = (index: number) => {
    setSelectedFlags(selectedFlags.filter((_, i) => i !== index));
  };

  const handleDownload = () => {
    if (!canvasRef.current || !selectedImage) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Redraw without control handles for download
    drawToCanvas(canvas, ctx, selectedImage, renderOptions, 0, patternImages, hatImages, selectedHat, hatSettings, false);
    
    // Download the canvas
    download(canvas);
    
    // Restore controls after download
    setTimeout(() => {
      drawToCanvas(canvas, ctx, selectedImage, renderOptions, 0, patternImages, hatImages, selectedHat, hatSettings, showHatControls);
    }, 100);
  };

  // Create render options for canvas drawing
  const renderOptions: CanvasDrawOptions = {
    cutoutSize,
    resizeInwards,
    selectedColors: selectedFlags.map(flag => flagColours[flag as keyof typeof flagColours] || []),
    isGradient,
    isRotating: rotating,
    animationLength,
    isRotatingCounterClockwise,
    overlayOpacity: 100, // Always fully visible as per designer feedback
    cutoutType,
    rotationOffset: overlayRotation,
    flagNames: selectedFlags
  };

  // Animation loop
  useEffect(() => {
    const animate = (timestamp: number) => {
      if (canvasRef.current && selectedImage) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          drawToCanvas(canvasRef.current, ctx, selectedImage, renderOptions, timestamp, patternImages, hatImages, selectedHat, hatSettings, showHatControls);
        }
      }
      
      if (rotating) {
        animationFrameRef.current = requestAnimationFrame(animate);
      }
    };

    if (rotating) {
      animationFrameRef.current = requestAnimationFrame(animate);
    } else if (canvasRef.current && selectedImage) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        drawToCanvas(canvasRef.current, ctx, selectedImage, renderOptions, 0, patternImages, hatImages, selectedHat, hatSettings, showHatControls);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [selectedImage, rotating, cutoutSize, cutoutType, overlayRotation, selectedFlags, patternImages, hatImages, selectedHat, hatSettings, showHatControls]);

  // Auto-show controls when hat is selected
  useEffect(() => {
    if (selectedHat) {
      setShowHatControls(true);
    } else {
      setShowHatControls(false);
    }
  }, [selectedHat]);

  return (
    <main style={{ 
      padding: window.innerWidth < 768 ? '10px' : '20px', 
      fontFamily: 'Outfit, Arial, sans-serif', 
      maxWidth: '100%', 
      margin: '0 auto',
      width: '100%',
      minHeight: '100vh'
    }}>
      <header style={{ textAlign: 'center', marginBottom: 'clamp(20px, 5vw, 40px)' }}>
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center', 
          gap: 'clamp(8px, 2vw, 15px)', 
          marginBottom: '10px',
          flexWrap: 'wrap'
        }}>
          <img 
            src="/mascot-header.png" 
            alt="P33ly Mascot" 
            style={{ height: 'clamp(32px, 6vw, 50px)', width: 'auto' }}
          />
          <h1 style={{ 
            fontSize: 'clamp(1.2rem, 5vw, 2.5rem)', 
            fontFamily: 'Outfit, sans-serif', 
            fontWeight: 700, 
            color: '#fff', 
            margin: 0,
            textAlign: 'center',
            lineHeight: 1.2
          }}>
            P33ly PFP Editor
          </h1>
        </div>
      </header>



      {/* File Input Section */}
      <section style={{ marginBottom: '40px', textAlign: 'center' }}>
        <h2 style={{ fontSize: 'clamp(1.2rem, 3vw, 1.5rem)', fontFamily: 'Outfit, sans-serif', fontWeight: 600, marginBottom: '20px', color: '#fff' }}>Upload X profile picture</h2>
        <div style={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          padding: '20px',
          borderRadius: '12px',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          maxWidth: '100%',
          margin: '0 auto'
        }}>
          <div
            style={{
              border: `2px dashed ${isDraggingOver ? 'rgba(255, 255, 255, 0.5)' : 'rgba(255, 255, 255, 0.3)'}`,
              borderRadius: '8px',
              padding: '40px 20px',
              textAlign: 'center',
              backgroundColor: isDraggingOver ? 'rgba(255, 255, 255, 0.1)' : 'transparent',
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <p style={{ fontSize: '1.2rem', marginBottom: '10px', color: '#fff' }}>
              📁 Drop your image here or click to browse
            </p>
            <p style={{ fontSize: '0.9rem', color: 'rgba(255, 255, 255, 0.7)' }}>
              Supports JPG, PNG, WebP and other image formats (max 10MB)
            </p>
            <input
              id="file-input"
              type="file"
              accept="image/*"
              onChange={handleFileInputChange}
              style={{ display: 'none' }}
            />
          </div>
          
          {selectedFiles.length > 0 && (
            <div style={{ marginTop: '20px' }}>
              <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)', padding: '15px', borderRadius: '8px', border: '1px solid rgba(255, 255, 255, 0.2)' }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '15px', color: '#fff' }}>File Statistics</h3>
                {selectedFiles.map((file, index) => (
                  <div key={index} style={{ marginBottom: '10px' }}>
                    <p style={{ fontSize: '0.9rem', color: 'rgba(255, 255, 255, 0.8)', margin: '5px 0' }}>
                      <strong>Name:</strong> {file.name}
                    </p>
                    <p style={{ fontSize: '0.9rem', color: 'rgba(255, 255, 255, 0.8)', margin: '5px 0' }}>
                      <strong>Size:</strong> {humanReadableFilesize(file.size)}
                    </p>
                    {selectedImage && (
                      <p style={{ fontSize: '0.9rem', color: 'rgba(255, 255, 255, 0.8)', margin: '5px 0' }}>
                        <strong>Dimensions:</strong> {getImageSize(selectedImage).width} × {getImageSize(selectedImage).height}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>



      {/* Preview Section - Always visible */}
      <section style={{ marginBottom: 'clamp(20px, 5vw, 40px)', textAlign: 'center' }} onClick={handleOutsideClick}>
        <h2 style={{ fontSize: 'clamp(1.1rem, 4vw, 1.5rem)', fontFamily: 'Outfit, sans-serif', fontWeight: 600, marginBottom: 'clamp(15px, 3vw, 20px)', color: '#fff' }}>Preview</h2>
        <div style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.1)', 
          padding: 'clamp(10px, 3vw, 20px)', 
          borderRadius: '12px', 
          border: '1px solid rgba(255, 255, 255, 0.2)',
          display: 'inline-block',
          maxWidth: '100%',
          position: 'relative',
          width: 'fit-content'
        }}>
          {selectedImage ? (
            <>
              <canvas
                ref={canvasRef}
                width={400}
                height={400}
                style={{
                  width: '100%',
                  maxWidth: 'min(400px, 90vw)',
                  height: 'auto',
                  borderRadius: '8px',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  display: 'block',
                  backgroundColor: '#fff',
                  cursor: selectedHat && !isDraggingHat ? 'grab' : isDraggingHat ? 'grabbing' : 'default',
                  aspectRatio: '1/1'
                }}
                onMouseDown={handleCanvasMouseDown}
                onMouseMove={handleCanvasMouseMove}
                onMouseUp={handleCanvasMouseUp}
                onMouseLeave={handleCanvasMouseLeave}
                onTouchStart={(e) => handleCanvasMouseDown(e as any)}
                onTouchMove={(e) => handleCanvasMouseMove(e as any)}
                onTouchEnd={(e) => handleCanvasMouseUp(e as any)}
                onClick={(e) => e.stopPropagation()}
              />
              

            </>
          ) : (
            <div style={{
              width: '400px',
              height: '400px',
              maxWidth: '100%',
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              border: '2px dashed rgba(255, 255, 255, 0.3)',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'rgba(255, 255, 255, 0.6)',
              fontSize: '1.1rem'
            }}>
              Upload an image to see preview
            </div>
          )}
        </div>
        
        {/* Download Button - Right below preview */}
        {selectedImage && (
          <div style={{ marginTop: 'clamp(15px, 3vw, 20px)' }}>
            <button
              onClick={handleDownload}
              style={{
                backgroundColor: '#ff4a00',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                padding: 'clamp(10px 20px, 3vw, 12px 24px)',
                cursor: 'pointer',
                fontSize: 'clamp(0.9rem, 3vw, 1rem)',
                fontWeight: 600,
                fontFamily: 'Outfit, sans-serif',
                minHeight: '44px',
                minWidth: '120px'
              }}
            >
              Download Image
            </button>
          </div>
        )}

        {/* Hat Control Mode Selection - Below download button */}
        {selectedHat && (
          <div style={{ marginTop: 'clamp(15px, 3vw, 20px)', padding: '12px', backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: '8px', maxWidth: '400px', margin: 'clamp(15px, 3vw, 20px) auto 0' }}>
            <p style={{ color: 'rgba(255, 255, 255, 0.8)', fontSize: '0.9rem', margin: '0 0 12px 0', textAlign: 'center' }}>
              Control Mode:
            </p>
            <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button
                onClick={() => setHatControlMode('move')}
                style={{
                  padding: '8px 12px',
                  borderRadius: '6px',
                  border: '2px solid',
                  borderColor: hatControlMode === 'move' ? '#0088ff' : 'rgba(255, 255, 255, 0.3)',
                  backgroundColor: hatControlMode === 'move' ? 'rgba(0, 136, 255, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.8rem',
                  fontFamily: 'Outfit, sans-serif',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
                title="Move Hat"
              >
                ✋ Move
              </button>
              <button
                onClick={() => setHatControlMode('resize')}
                style={{
                  padding: '8px 12px',
                  borderRadius: '6px',
                  border: '2px solid',
                  borderColor: hatControlMode === 'resize' ? '#ff4a00' : 'rgba(255, 255, 255, 0.3)',
                  backgroundColor: hatControlMode === 'resize' ? 'rgba(255, 74, 0, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.8rem',
                  fontFamily: 'Outfit, sans-serif',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
                title="Resize Hat"
              >
                ⚡ Resize
              </button>
              <button
                onClick={() => setHatControlMode('rotate')}
                style={{
                  padding: '8px 12px',
                  borderRadius: '6px',
                  border: '2px solid',
                  borderColor: hatControlMode === 'rotate' ? '#00ff00' : 'rgba(255, 255, 255, 0.3)',
                  backgroundColor: hatControlMode === 'rotate' ? 'rgba(0, 255, 0, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.8rem',
                  fontFamily: 'Outfit, sans-serif',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
                title="Rotate Hat"
              >
                🔄 Rotate
              </button>
            </div>
          </div>
        )}
      </section>

      {/* P33ly Frame Options Section */}
      <section style={{ marginBottom: 'clamp(20px, 5vw, 40px)', textAlign: 'center' }}>
        <h2 style={{ fontSize: 'clamp(1rem, 4vw, 1.5rem)', fontFamily: 'Outfit, sans-serif', fontWeight: 600, marginBottom: 'clamp(15px, 3vw, 20px)', color: '#fff' }}>P33ly Frame Options</h2>
        <div style={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          padding: 'clamp(15px, 4vw, 20px)',
          borderRadius: '12px',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          maxWidth: '100%',
          margin: '0 auto',
          textAlign: 'left'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '12px', fontWeight: 500, color: '#fff', fontSize: '1rem' }}>
              Choose P33ly Frame
            </label>
            <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth < 768 ? '1fr' : '1fr 1fr', gap: 'clamp(8px, 2vw, 12px)' }}>
              {/* No Frame option */}
              <button
                onClick={() => setSelectedFlags([])}
                style={{
                  padding: '12px 16px',
                  borderRadius: '8px',
                  border: '2px solid',
                  borderColor: selectedFlags.length === 0 ? '#ff4a00' : 'rgba(255, 255, 255, 0.3)',
                  backgroundColor: selectedFlags.length === 0 ? 'rgba(255, 74, 0, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.9rem',
                  fontWeight: 500,
                  fontFamily: 'Outfit, sans-serif',
                  transition: 'all 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  justifyContent: 'center'
                }}
              >
                No Frame
              </button>
              {Object.keys(flagColours).map((flagName) => (
                <button
                  key={flagName}
                  onClick={() => setSelectedFlags([flagName])}
                  style={{
                    padding: '12px 16px',
                    borderRadius: '8px',
                    border: '2px solid',
                    borderColor: selectedFlags.includes(flagName) ? '#ff4a00' : 'rgba(255, 255, 255, 0.3)',
                    backgroundColor: selectedFlags.includes(flagName) ? 'rgba(255, 74, 0, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                    color: '#fff',
                    cursor: 'pointer',
                    fontSize: '0.9rem',
                    fontWeight: 500,
                    fontFamily: 'Outfit, sans-serif',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    justifyContent: 'center'
                  }}
                >
                  <img 
                    src="/mascot.png" 
                    alt="P33ly Mascot" 
                    style={{ height: '20px', width: 'auto' }}
                  />
                  {flagName}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Hat Selection Section */}
      <section style={{ marginBottom: '40px', textAlign: 'center' }}>
        <h2 style={{ fontSize: 'clamp(1.2rem, 3vw, 1.5rem)', fontFamily: 'Outfit, sans-serif', fontWeight: 600, marginBottom: '20px', color: '#fff' }}>Add P33ly Hat</h2>
        <div style={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          padding: '20px',
          borderRadius: '12px',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          maxWidth: '100%',
          margin: '0 auto',
          textAlign: 'left'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '12px', fontWeight: 500, color: '#fff', fontSize: '1rem' }}>
              Choose Hat
            </label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: '12px' }}>
              <button
                onClick={() => setSelectedHat(null)}
                style={{
                  padding: '12px 16px',
                  borderRadius: '8px',
                  border: '2px solid',
                  borderColor: selectedHat === null ? '#ff4a00' : 'rgba(255, 255, 255, 0.3)',
                  backgroundColor: selectedHat === null ? 'rgba(255, 74, 0, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.9rem',
                  fontFamily: 'Outfit, sans-serif',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '8px',
                  minHeight: '60px'
                }}
              >
                No Hat
              </button>
              {Object.keys(hatImages).map((hatName) => (
                <button
                  key={hatName}
                  onClick={() => {
                    setSelectedHat(hatName);
                    setShowHatControls(true);
                  }}
                  style={{
                    padding: '12px 16px',
                    borderRadius: '8px',
                    border: '2px solid',
                    borderColor: selectedHat === hatName ? '#ff4a00' : 'rgba(255, 255, 255, 0.3)',
                    backgroundColor: selectedHat === hatName ? 'rgba(255, 74, 0, 0.2)' : 'rgba(255, 255, 255, 0.1)',
                    color: '#fff',
                    cursor: 'pointer',
                    fontSize: '0.9rem',
                    fontFamily: 'Outfit, sans-serif',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                    minHeight: '60px',
                    flexDirection: 'column'
                  }}
                >
                  <img 
                    src="/mascot.png" 
                    alt="P33ly Mascot" 
                    style={{ height: '20px', width: 'auto' }}
                  />
                  {hatName}
                </button>
              ))}
            </div>
          </div>

          {/* Hat Controls */}
          {selectedHat && (
            <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid rgba(255, 255, 255, 0.2)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <h3 style={{ color: '#fff', fontSize: '1rem', margin: 0 }}>Hat Settings</h3>
                <button
                  onClick={() => {
                    setSelectedHat(null);
                    setShowHatControls(false);
                  }}
                  style={{
                    padding: '6px 10px',
                    borderRadius: '6px',
                    border: '2px solid rgba(255, 255, 255, 0.3)',
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    color: '#fff',
                    cursor: 'pointer',
                    fontSize: '0.8rem',
                    fontFamily: 'Outfit, sans-serif',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    transition: 'all 0.2s ease'
                  }}
                  title="Remove Hat"
                >
                  ✕ Remove
                </button>
              </div>
              




            </div>
          )}
        </div>
      </section>

      {/* P33ly Frame Settings */}
      <section style={{ marginBottom: '40px', textAlign: 'center' }}>
        <h2 style={{ fontSize: 'clamp(1.2rem, 3vw, 1.5rem)', fontFamily: 'Outfit, sans-serif', fontWeight: 600, marginBottom: '20px', color: '#fff' }}>P33ly Frame Settings</h2>
        <div style={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          padding: '20px',
          borderRadius: '12px',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          maxWidth: '100%',
          margin: '0 auto',
          textAlign: 'left'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#fff' }}>
              Cutout size: {cutoutSize}%
            </label>
            <input
              type="range"
              min="30"
              max="100"
              step="1"
              value={cutoutSize}
              onChange={(e) => setCutoutSize(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#ff4a00' }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#fff' }}>
              Shape
            </label>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <button
                onClick={() => setCutoutType(CutoutType.CIRCLE)}
                style={{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  backgroundColor: cutoutType === CutoutType.CIRCLE ? '#ff4a00' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                Circle
              </button>
              <button
                onClick={() => setCutoutType(CutoutType.SQUARE)}
                style={{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  backgroundColor: cutoutType === CutoutType.SQUARE ? '#ff4a00' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                Square
              </button>
              <button
                onClick={() => setCutoutType(CutoutType.OVERLAY)}
                style={{
                  padding: '8px 16px',
                  borderRadius: '6px',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  backgroundColor: cutoutType === CutoutType.OVERLAY ? '#ff4a00' : 'rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                Full
              </button>
            </div>
          </div>



          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#fff' }}>
              Frame rotation: {overlayRotation}°
            </label>
            <input
              type="range"
              min="0"
              max="360"
              value={overlayRotation}
              onChange={(e) => setOverlayRotation(Number(e.target.value))}
              style={{ width: '100%', accentColor: '#ff4a00' }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={rotating}
                onChange={(e) => setRotating(e.target.checked)}
                style={{ accentColor: '#ff4a00' }}
              />
              <span style={{ fontWeight: 500, color: '#fff' }}>Rotating animation</span>
            </label>
          </div>

          {rotating && (
            <>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, color: '#fff' }}>
                  Animation speed: {animationLength}s
                </label>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={animationLength}
                  onChange={(e) => setAnimationLength(Number(e.target.value))}
                  style={{ width: '100%', accentColor: '#ff4a00' }}
                />
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={isRotatingCounterClockwise}
                    onChange={(e) => setIsRotatingCounterClockwise(e.target.checked)}
                    style={{ accentColor: '#ff4a00' }}
                  />
                  <span style={{ fontWeight: 500, color: '#fff' }}>Counter-clockwise</span>
                </label>
              </div>
            </>
          )}
        </div>


      </section>

      <footer style={{ textAlign: 'center', marginTop: '60px', padding: '30px 20px', borderTop: '1px solid rgba(255, 255, 255, 0.2)' }}>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center', 
          gap: '30px', 
          marginBottom: '20px',
          flexWrap: 'wrap'
        }}>
          <a href="https://x.com/thep33l" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
            <img 
              src="https://cdn.prod.website-files.com/682c59e31b429a7d5a7423d3/682c66b11d37111ae3338e42_Vector.svg"
              alt="X (Twitter)" 
              style={{ height: '32px', width: 'auto', opacity: 0.8, transition: 'opacity 0.3s ease' }}
              onMouseOver={(e) => e.currentTarget.style.opacity = '1'}
              onMouseOut={(e) => e.currentTarget.style.opacity = '0.8'}
            />
          </a>
          
          <div style={{ width: '1px', height: '40px', backgroundColor: 'rgba(255, 255, 255, 0.3)' }}></div>
          
          <a href="https://t.me/thep33lchat" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
            <img 
              src="https://cdn.prod.website-files.com/682c59e31b429a7d5a7423d3/682c66b1de95caa8537e8398_Vector.svg"
              alt="Telegram" 
              style={{ height: '32px', width: 'auto', opacity: 0.8, transition: 'opacity 0.3s ease' }}
              onMouseOver={(e) => e.currentTarget.style.opacity = '1'}
              onMouseOut={(e) => e.currentTarget.style.opacity = '0.8'}
            />
          </a>
          
          <div style={{ width: '1px', height: '40px', backgroundColor: 'rgba(255, 255, 255, 0.3)' }}></div>
          
          <a href="https://memedepot.com/d/thep33l" target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
            <img 
              src="https://cdn.prod.website-files.com/682c59e31b429a7d5a7423d3/682f60e80e0559ca860b3fcc_Meme%20Depot%20Logo.svg"
              alt="Meme Depot" 
              style={{ height: '32px', width: 'auto', opacity: 0.8, transition: 'opacity 0.3s ease' }}
              onMouseOver={(e) => e.currentTarget.style.opacity = '1'}
              onMouseOut={(e) => e.currentTarget.style.opacity = '0.8'}
            />
          </a>
        </div>
        
        <div style={{ 
          marginBottom: '20px', 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center' 
        }}>
          <img 
            src="https://cdn.prod.website-files.com/682c59e31b429a7d5a7423d3/682c66b10dd935267c7799d5_whitelogo-c.svg"
            alt="P33ly Logo" 
            style={{ height: '60px', width: 'auto', opacity: 0.9 }}
          />
        </div>
        
        <p style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '0.9rem', margin: 0 }}>
          Your images are processed locally and never uploaded to our servers.
        </p>
      </footer>
    </main>
  );
}
