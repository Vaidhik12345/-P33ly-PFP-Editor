import { useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, CloudUpload } from 'lucide-react';
import { samplePhotos } from '@/lib/flag-data';
import { loadImageFromFile, loadImageFromUrl } from '@/lib/canvas-utils';

interface ImageUploadProps {
  onImageLoad: (image: HTMLImageElement) => void;
  className?: string;
}

export default function ImageUpload({ onImageLoad, className }: ImageUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileSelect = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file.');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      alert('File size should be less than 10MB.');
      return;
    }

    setIsLoading(true);
    try {
      const image = await loadImageFromFile(file);
      onImageLoad(image);
    } catch (error) {
      alert('Failed to load image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [onImageLoad]);

  const handleSamplePhotoClick = useCallback(async (url: string) => {
    setIsLoading(true);
    try {
      const image = await loadImageFromUrl(url);
      onImageLoad(image);
    } catch (error) {
      alert('Failed to load sample image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [onImageLoad]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  return (
    <Card className={`p-6 ${className}`}>
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        <Upload className="text-indigo-600 mr-2 inline-block w-5 h-5" />
        Upload Your Photo
      </h3>
      
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
          isDragOver ? 'drag-over' : 'border-gray-300 hover:border-indigo-400'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => document.getElementById('file-input')?.click()}
      >
        <div className="space-y-4">
          <div className="mx-auto w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center">
            <CloudUpload className="text-2xl text-indigo-600 w-8 h-8" />
          </div>
          <div>
            <p className="text-lg font-medium text-gray-900">Drop your image here</p>
            <p className="text-gray-500">or click to browse</p>
          </div>
          <Button 
            className="bg-indigo-600 text-white hover:bg-indigo-700"
            disabled={isLoading}
          >
            {isLoading ? 'Loading...' : 'Choose File'}
          </Button>
          <p className="text-sm text-gray-400">Supports JPG, PNG, WebP up to 10MB</p>
        </div>
        
        <input
          id="file-input"
          type="file"
          accept="image/*"
          onChange={handleFileInputChange}
          className="hidden"
        />
      </div>

      <div className="mt-6">
        <p className="text-sm font-medium text-gray-700 mb-3">Or try with sample photos:</p>
        <div className="grid grid-cols-3 gap-2">
          {samplePhotos.map((url, index) => (
            <img
              key={index}
              src={url}
              alt={`Sample profile ${index + 1}`}
              className="w-full h-20 object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
              onClick={() => handleSamplePhotoClick(url)}
            />
          ))}
        </div>
      </div>
    </Card>
  );
}
