import { useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, Share2 } from 'lucide-react';
import { CanvasState, drawImageWithOverlay, downloadCanvas } from '@/lib/canvas-utils';

interface DownloadSectionProps {
  canvasState: CanvasState;
  className?: string;
}

export default function DownloadSection({ canvasState, className }: DownloadSectionProps) {
  const downloadCanvasRef = useRef<HTMLCanvasElement>(null);

  const handleDownload = (format: string = 'png', size: string = 'original') => {
    if (!canvasState.originalImage || !downloadCanvasRef.current) return;

    const canvas = downloadCanvasRef.current;
    let width = canvasState.originalImage.width;
    let height = canvasState.originalImage.height;

    // Adjust size based on selection
    if (size !== 'original') {
      const targetSize = parseInt(size);
      width = targetSize;
      height = targetSize;
    }

    canvas.width = width;
    canvas.height = height;

    // Draw the final image
    drawImageWithOverlay(canvas, canvasState);

    // Download
    const filename = `pride-pfp.${format}`;
    downloadCanvas(canvas, filename, format);
  };

  const handleShare = (platform: string) => {
    const text = "Check out my new pride profile picture! 🏳️‍🌈 Made with Pride PFP";
    const url = window.location.href;
    
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`);
        break;
      case 'instagram':
        // Instagram doesn't support direct sharing URLs, so just copy text
        navigator.clipboard.writeText(text);
        alert('Text copied to clipboard! You can now paste it on Instagram.');
        break;
    }
  };

  const hasImage = canvasState.originalImage !== null;

  return (
    <div className={`space-y-6 ${className}`}>
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          <Download className="text-purple-600 mr-2 inline-block w-5 h-5" />
          Download Your Pride PFP
        </h3>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Format</label>
              <Select defaultValue="png">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="png">PNG (Recommended)</SelectItem>
                  <SelectItem value="jpeg">JPEG</SelectItem>
                  <SelectItem value="webp">WebP</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Size</label>
              <Select defaultValue="original">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="original">Original Size</SelectItem>
                  <SelectItem value="500">500x500</SelectItem>
                  <SelectItem value="400">400x400</SelectItem>
                  <SelectItem value="300">300x300</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold hover:from-pink-600 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg"
            onClick={() => handleDownload()}
            disabled={!hasImage}
          >
            <Download className="mr-2 w-4 h-4" />
            Download Pride PFP
          </Button>
          
          <div className="text-center">
            <p className="text-sm text-gray-500">
              Your image is processed locally and never uploaded to our servers
            </p>
          </div>
        </div>
        
        <canvas
          ref={downloadCanvasRef}
          className="hidden"
          width={300}
          height={300}
        />
      </Card>

      <Card className="bg-gradient-to-br from-pink-50 to-purple-50 border border-pink-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          <Share2 className="text-pink-600 mr-2 inline-block w-5 h-5" />
          Share Your Pride
        </h3>
        <p className="text-gray-600 mb-4">
          Show your support by sharing your new pride profile picture!
        </p>
        <div className="flex space-x-3">
          <Button
            className="flex-1 bg-blue-600 text-white hover:bg-blue-700"
            onClick={() => handleShare('twitter')}
          >
            <i className="fab fa-twitter mr-2"></i>Twitter
          </Button>
          <Button
            className="flex-1 bg-blue-800 text-white hover:bg-blue-900"
            onClick={() => handleShare('facebook')}
          >
            <i className="fab fa-facebook mr-2"></i>Facebook
          </Button>
          <Button
            className="flex-1 bg-pink-600 text-white hover:bg-pink-700"
            onClick={() => handleShare('instagram')}
          >
            <i className="fab fa-instagram mr-2"></i>Instagram
          </Button>
        </div>
      </Card>
    </div>
  );
}
