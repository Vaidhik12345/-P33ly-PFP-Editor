import { useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Eye } from 'lucide-react';
import { CanvasState, OverlayPosition, drawImageWithOverlay } from '@/lib/canvas-utils';

interface CanvasPreviewProps {
  canvasState: CanvasState;
  onOpacityChange: (opacity: number) => void;
  onPositionChange: (position: OverlayPosition) => void;
  className?: string;
}

const positionOptions: { label: string; value: OverlayPosition; icon: string }[] = [
  { label: 'Top Left', value: 'top-left', icon: '↖' },
  { label: 'Top Right', value: 'top-right', icon: '↗' },
  { label: 'Full', value: 'full', icon: '⛶' },
  { label: 'Bottom Left', value: 'bottom-left', icon: '↙' },
  { label: 'Bottom Right', value: 'bottom-right', icon: '↘' },
  { label: 'Center', value: 'center', icon: '⊙' },
];

export default function CanvasPreview({ 
  canvasState, 
  onOpacityChange, 
  onPositionChange, 
  className 
}: CanvasPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current) {
      drawImageWithOverlay(canvasRef.current, canvasState);
    }
  }, [canvasState]);

  const hasImage = canvasState.originalImage !== null;

  return (
    <Card className={`p-6 ${className}`}>
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        <Eye className="text-green-600 mr-2 inline-block w-5 h-5" />
        Preview
      </h3>
      
      <div className="flex justify-center mb-6">
        <div className="canvas-container">
          {hasImage ? (
            <canvas
              ref={canvasRef}
              width={300}
              height={300}
              className="border rounded-xl shadow-sm bg-gray-100"
            />
          ) : (
            <div className="w-72 h-72 bg-gray-100 border rounded-xl flex items-center justify-center">
              <div className="text-center text-gray-400">
                <Eye className="mx-auto mb-2 w-12 h-12" />
                <p>Upload an image to see preview</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {hasImage && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Overlay Opacity
            </label>
            <Slider
              value={[canvasState.overlayOpacity]}
              onValueChange={(value) => onOpacityChange(value[0])}
              max={100}
              min={0}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Transparent</span>
              <span>Opaque</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Position
            </label>
            <div className="grid grid-cols-3 gap-2">
              {positionOptions.map((option) => (
                <Button
                  key={option.value}
                  variant="outline"
                  size="sm"
                  className={`text-sm ${
                    canvasState.overlayPosition === option.value 
                      ? 'position-btn selected' 
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => onPositionChange(option.value)}
                >
                  {option.icon} {option.label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}
