import { Card } from '@/components/ui/card';
import { Flag } from 'lucide-react';
import { prideFlags, PrideFlag } from '@/lib/flag-data';

interface FlagSelectorProps {
  selectedFlag: PrideFlag | null;
  onFlagSelect: (flag: PrideFlag) => void;
  className?: string;
}

export default function FlagSelector({ selectedFlag, onFlagSelect, className }: FlagSelectorProps) {
  return (
    <Card className={`p-6 ${className}`}>
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        <Flag className="text-pink-600 mr-2 inline-block w-5 h-5" />
        Choose Pride Flag
      </h3>
      
      <div className="grid grid-cols-2 gap-3">
        {prideFlags.map((flag) => (
          <div
            key={flag.id}
            className={`flag-option border-2 border-transparent rounded-lg p-3 cursor-pointer hover:border-indigo-400 transition-colors ${
              selectedFlag?.id === flag.id ? 'selected' : ''
            }`}
            onClick={() => onFlagSelect(flag)}
          >
            <div 
              className="h-12 rounded mb-2"
              style={{ background: flag.gradient }}
            />
            <p className="text-sm font-medium text-gray-900">{flag.name}</p>
            <p className="text-xs text-gray-500">{flag.shortName}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
