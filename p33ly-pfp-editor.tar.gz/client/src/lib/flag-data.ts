export const flagColours = {
    "P33LY in Love": [
        "#ff4a00",
        "#ff4a00",
        "#ff4a00",
        "#ff4a00"
    ],
    "P33LY Peek": [
        "#ff4a00",
        "#ff4a00",
        "#ff4a00",
        "#ff4a00"
    ]
};

export const patternImages = {
    "No Frame": null,
    "P33LY in Love": "/frame1.png",
    "P33LY Peek": "/frame2.png"
};

export const samplePhotos = [
  '/Untitled_1750142643209.jpg',
  'https://images.unsplash.com/photo-1494790108755-2616c24ce016?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400',
  'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400',
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400'
];
