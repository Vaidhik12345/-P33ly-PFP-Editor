import { CanvasDrawOptions, CutoutType } from './types';

function degToRad(degrees: number): number {
    return degrees * (Math.PI / 180);
}

function isImageOk(img: HTMLImageElement): boolean {
    return img.complete && img.naturalHeight !== 0;
}



export function drawToCanvas(
    canvas: HTMLCanvasElement, 
    ctx: CanvasRenderingContext2D, 
    selectedImage: HTMLImageElement | null, 
    options: CanvasDrawOptions, 
    now: number,
    patternImages?: {[key: string]: HTMLImageElement},
    hatImages?: {[key: string]: HTMLImageElement},
    selectedHat?: string | null,
    hatSettings?: {
        scale: number;
        rotation: number;
        positionX: number;
        positionY: number;
        flipHorizontal: boolean;
        flipVertical: boolean;
    },
    showHatControls?: boolean
) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Set white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const flagName = options.flagNames?.[0];
    const isP33lyFrame = flagName && (flagName.includes('P33LY') || flagName.includes('P33ly Frame'));

    if (isP33lyFrame) {
        // For P33ly frames: Apply cutout size effect to user image
        if (selectedImage && isImageOk(selectedImage)) {
            ctx.save();
            
            // Calculate cutout area based on cutoutSize setting
            const cutoutSizePercent = options.cutoutSize / 100;
            const cutoutWidth = canvas.width * cutoutSizePercent;
            const cutoutHeight = canvas.height * cutoutSizePercent;
            const cutoutX = (canvas.width - cutoutWidth) / 2;
            const cutoutY = (canvas.height - cutoutHeight) / 2;
            
            // Create clipping mask for the visible area
            ctx.beginPath();
            if (options.cutoutType === CutoutType.CIRCLE) {
                const centerX = canvas.width / 2;
                const centerY = canvas.height / 2;
                const radius = Math.min(cutoutWidth, cutoutHeight) / 2;
                ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
            } else if (options.cutoutType === CutoutType.SQUARE) {
                ctx.rect(cutoutX, cutoutY, cutoutWidth, cutoutHeight);
            } else {
                // OVERLAY - full image
                ctx.rect(0, 0, canvas.width, canvas.height);
            }
            ctx.clip();
            
            // Draw user image scaled to cover the entire cutout area
            if (options.cutoutType === CutoutType.OVERLAY) {
                // Full overlay mode - show entire image
                ctx.drawImage(selectedImage, 0, 0, canvas.width, canvas.height);
            } else {
                // Scale image to cover cutout area completely (like object-fit: cover)
                const imgAspect = selectedImage.width / selectedImage.height;
                const cutoutAspect = cutoutWidth / cutoutHeight;
                
                let drawWidth, drawHeight, drawX, drawY;
                
                if (imgAspect > cutoutAspect) {
                    // Image is wider - scale to cover cutout width
                    drawWidth = cutoutWidth;
                    drawHeight = drawWidth / imgAspect;
                    drawX = cutoutX;
                    drawY = cutoutY + (cutoutHeight - drawHeight) / 2;
                } else {
                    // Image is taller - scale to cover cutout height  
                    drawHeight = cutoutHeight;
                    drawWidth = drawHeight * imgAspect;
                    drawX = cutoutX + (cutoutWidth - drawWidth) / 2;
                    drawY = cutoutY;
                }
                
                // Ensure image covers the entire cutout area
                if (drawWidth < cutoutWidth) {
                    const scale = cutoutWidth / drawWidth;
                    drawWidth *= scale;
                    drawHeight *= scale;
                    drawX = cutoutX + (cutoutWidth - drawWidth) / 2;
                    drawY = cutoutY + (cutoutHeight - drawHeight) / 2;
                }
                if (drawHeight < cutoutHeight) {
                    const scale = cutoutHeight / drawHeight;
                    drawWidth *= scale;
                    drawHeight *= scale;
                    drawX = cutoutX + (cutoutWidth - drawWidth) / 2;
                    drawY = cutoutY + (cutoutHeight - drawHeight) / 2;
                }
                
                ctx.drawImage(selectedImage, drawX, drawY, drawWidth, drawHeight);
            }
            
            ctx.restore();
        }
        

        
        // Draw P33ly frame overlay on top with all effects
        if (patternImages && patternImages[flagName]) {
            const frameImg = patternImages[flagName];
            if (isImageOk(frameImg)) {
                ctx.save();
                
                // Apply rotation (static + animated)
                const centerX = canvas.width / 2;
                const centerY = canvas.height / 2;
                ctx.translate(centerX, centerY);
                
                let totalRotation = options.rotationOffset;
                
                // Add animated rotation if enabled
                if (options.isRotating) {
                    const animationSpeed = (2 * Math.PI) / (options.animationLength * 1000);
                    const animatedRotation = (now * animationSpeed) % (2 * Math.PI);
                    totalRotation += (animatedRotation * 180) / Math.PI;
                    
                    if (options.isRotatingCounterClockwise) {
                        totalRotation = -totalRotation;
                    }
                }
                
                if (totalRotation !== 0) {
                    ctx.rotate((totalRotation * Math.PI) / 180);
                }
                
                ctx.translate(-centerX, -centerY);
                
                // Apply opacity and draw frame
                ctx.globalAlpha = options.overlayOpacity / 100;
                ctx.drawImage(frameImg, 0, 0, canvas.width, canvas.height);
                
                ctx.restore();
            }
        }
    } else {
        // Original logic for pattern backgrounds
        if (flagName && patternImages && patternImages[flagName]) {
            const img = patternImages[flagName];
            const pattern = ctx.createPattern(img, 'repeat');
            if (pattern) {
                ctx.fillStyle = pattern;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            }
        }

        // Draw uploaded image with cutout shape for non-frame patterns
        if (selectedImage && isImageOk(selectedImage)) {
            const size = (canvas.width * options.cutoutSize) / 100;
            const x = (canvas.width - size) / 2;
            const y = (canvas.height - size) / 2;
            
            ctx.save();
            
            // Create clipping path based on cutout type
            ctx.beginPath();
            if (options.cutoutType === CutoutType.CIRCLE) {
                const centerX = canvas.width / 2;
                const centerY = canvas.height / 2;
                const radius = size / 2;
                ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
            } else if (options.cutoutType === CutoutType.SQUARE) {
                ctx.rect(x, y, size, size);
            } else {
                ctx.rect(0, 0, canvas.width, canvas.height);
            }
            ctx.clip();
            
            if (options.cutoutType === CutoutType.OVERLAY) {
                ctx.drawImage(selectedImage, 0, 0, canvas.width, canvas.height);
            } else {
                ctx.drawImage(selectedImage, x, y, size, size);
            }
            
            ctx.restore();
        }
    }

    // Draw hat overlay (always draw hat regardless of frame selection)
    if (selectedHat && hatImages && hatImages[selectedHat] && hatSettings) {
        const hatImg = hatImages[selectedHat];
        if (isImageOk(hatImg)) {
            ctx.save();
            
            // Calculate hat size and position
            const hatBaseSize = Math.min(canvas.width, canvas.height) * 0.3; // Base size is 30% of canvas
            const hatWidth = hatBaseSize * hatSettings.scale;
            const hatHeight = (hatImg.height / hatImg.width) * hatWidth;
            
            // Position calculations
            const centerX = canvas.width / 2;
            const centerY = canvas.height / 2;
            const hatX = centerX + (hatSettings.positionX / 100) * canvas.width - hatWidth / 2;
            const hatY = centerY + (hatSettings.positionY / 100) * canvas.height - hatHeight / 2;
            
            // Apply transformations
            ctx.translate(hatX + hatWidth / 2, hatY + hatHeight / 2);
            
            if (hatSettings.rotation !== 0) {
                ctx.rotate(degToRad(hatSettings.rotation));
            }
            
            if (hatSettings.flipHorizontal || hatSettings.flipVertical) {
                ctx.scale(
                    hatSettings.flipHorizontal ? -1 : 1,
                    hatSettings.flipVertical ? -1 : 1
                );
            }
            
            // Draw hat
            ctx.drawImage(hatImg, -hatWidth / 2, -hatHeight / 2, hatWidth, hatHeight);
            
            ctx.restore();
        }
    }

    // Draw hat control handles if enabled
    if (selectedHat && showHatControls && hatSettings) {
        const hatBaseSize = Math.min(canvas.width, canvas.height) * 0.3;
        const hatWidth = hatBaseSize * hatSettings.scale;
        const hatHeight = hatWidth;
        
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const hatX = centerX + (hatSettings.positionX / 100) * canvas.width;
        const hatY = centerY + (hatSettings.positionY / 100) * canvas.height;
        
        const handleSize = 8;
        
        // Three circular control buttons - dynamically positioned relative to hat size
        const buttonRadius = 10;
        const insetRatio = 0.15; // 15% inset from hat edges (scales with hat size)
        const dynamicInset = Math.max(12, Math.min(hatWidth, hatHeight) * insetRatio);
        
        const controlButtons = [
            { 
                x: hatX - hatWidth/2 + dynamicInset, 
                y: hatY - hatHeight/2 + dynamicInset, 
                type: 'move', 
                color: '#0088ff', 
                icon: '✋' 
            },
            { 
                x: hatX + hatWidth/2 - dynamicInset, 
                y: hatY - hatHeight/2 + dynamicInset, 
                type: 'resize', 
                color: '#ff4a00', 
                icon: '⚡' 
            },
            { 
                x: hatX, 
                y: hatY + hatHeight/2 - dynamicInset, 
                type: 'rotate', 
                color: '#00ff00', 
                icon: '🔄' 
            }
        ];

        ctx.save();
        
        // Draw three circular control buttons with enhanced visibility
        controlButtons.forEach((button) => {
            // Draw shadow for better visibility
            ctx.beginPath();
            ctx.arc(button.x + 2, button.y + 2, buttonRadius, 0, 2 * Math.PI);
            ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
            ctx.fill();
            
            // Draw filled circle
            ctx.beginPath();
            ctx.arc(button.x, button.y, buttonRadius, 0, 2 * Math.PI);
            ctx.fillStyle = button.color;
            ctx.fill();
            
            // Draw white border
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 3;
            ctx.stroke();
            
            // Draw icon text with better visibility
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 18px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
            ctx.shadowBlur = 2;
            ctx.fillText(button.icon, button.x, button.y);
            ctx.shadowBlur = 0;
        });
        
        ctx.restore();
    }
}

function drawFlag(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D, options: CanvasDrawOptions, now: number) {
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);

    if (options.rotationOffset % 360 != 0) {
        ctx.rotate(degToRad(options.rotationOffset % 360));
    }

    if (options.isRotating) {
        ctx.rotate(
            degToRad(
                (now / options.animationLength) *
                360 *
                (options.isRotatingCounterClockwise ? -1 : 1)
                + options.rotationOffset
            )
        );
    }

    ctx.translate(canvas.width / -2, canvas.height / -2);

    ctx.globalAlpha = options.overlayOpacity / 100;

    for (let j = 0; j < options.selectedColors.length; j++) {
        let x = j == 0 ? -canvas.width / 2 : canvas.width / options.selectedColors.length * j;
        let w = canvas.width / options.selectedColors.length + (j == 0 || j == options.selectedColors.length - 1 ? canvas.width / 2 : 0);

        ctx.save();
        ctx.beginPath();
        ctx.rect(
            x,
            -canvas.height / 2,
            w,
            canvas.height * 2
        );
        ctx.clip();

        if (!options.isGradient) {
            for (let i = 0; i < options.selectedColors[j].length; i++) {
                ctx.fillStyle = options.selectedColors[j][i];
                ctx.fillRect(
                    -canvas.width / 2,
                    i == 0
                        ? -canvas.height / 2
                        : (i * canvas.height) / options.selectedColors[j].length,
                    canvas.width * 2,
                    ([0, options.selectedColors[j].length - 1].includes(i)
                        ? canvas.height / 2
                        : 0) +
                    canvas.height / options.selectedColors[j].length
                );
            }
        } else {
            let gradient = ctx.createLinearGradient(
                canvas.width / 2,
                0,
                canvas.width / 2,
                canvas.height
            );

            for (let i = 0; i < options.selectedColors[j].length; i++) {
                gradient.addColorStop(
                    i / (options.selectedColors[j].length - 1),
                    options.selectedColors[j][i]
                );
            }

            ctx.fillStyle = gradient;
            ctx.fillRect(
                -canvas.width / 2,
                -canvas.height / 2,
                canvas.width * 2,
                canvas.height * 2
            );
        }

        ctx.restore();
    }

    ctx.restore();
}



export function generateFlag(colors: string[], flagName?: string): string {
    const canvas = document.createElement('canvas');
    canvas.width = 100;
    canvas.height = 60;
    const ctx = canvas.getContext('2d')!;
    
    // Pattern mapping for different custom patterns
    const patternImages: { [key: string]: string } = {
        "custom emoji pattern": "/pattern3.jpg",
        "custom emoji pattern 2": "/pattern1.jpg",
        "custom emoji pattern 3": "/pattern2.jpg"
    };

    if (flagName && patternImages[flagName]) {
        // Create a preview showing pattern indicator
        ctx.fillStyle = colors[0];
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Add pattern indicator
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.fillRect(0, 0, canvas.width, 12);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 8px Arial';
        ctx.fillText('PATTERN', 2, 9);
    } else {
        // Default color stripes for other flags
        for (let i = 0; i < colors.length; i++) {
            ctx.fillStyle = colors[i];
            ctx.fillRect(0, (i * canvas.height) / colors.length, canvas.width, canvas.height / colors.length);
        }
    }
    
    return canvas.toDataURL();
}

export function fileToImage(file: File): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = e.target?.result as string;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

export function getImageSize(img: HTMLImageElement): { width: number; height: number } {
    return { width: img.naturalWidth, height: img.naturalHeight };
}

export function humanReadableFilesize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function capitalise(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

export function download(canvas: HTMLCanvasElement, filename: string = 'p33l_pfp.png') {
    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL();
    link.click();
}