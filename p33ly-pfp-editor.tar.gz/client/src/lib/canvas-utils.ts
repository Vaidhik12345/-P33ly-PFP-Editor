import { PrideFlag } from './flag-data';

export type OverlayPosition = 'full' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'center';

export interface CanvasState {
  originalImage: HTMLImageElement | null;
  selectedFlag: PrideFlag | null;
  overlayOpacity: number;
  overlayPosition: OverlayPosition;
}

export function createFlagCanvas(flag: PrideFlag, width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Create gradient based on flag colors
  let gradient;
  if (flag.colors.length <= 3) {
    gradient = ctx.createLinearGradient(0, 0, 0, height);
    flag.colors.forEach((color, index) => {
      gradient.addColorStop(index / (flag.colors.length - 1), color);
    });
  } else {
    gradient = ctx.createLinearGradient(0, 0, 0, height);
    const stripeHeight = height / flag.colors.length;
    flag.colors.forEach((color, index) => {
      const start = index / flag.colors.length;
      const end = (index + 1) / flag.colors.length;
      gradient.addColorStop(start, color);
      gradient.addColorStop(end, color);
    });
  }

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  return canvas;
}

export function drawImageWithOverlay(
  canvas: HTMLCanvasElement,
  state: CanvasState
): void {
  const ctx = canvas.getContext('2d')!;
  
  if (!state.originalImage || !state.selectedFlag) return;

  // Clear canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw original image
  ctx.drawImage(state.originalImage, 0, 0, canvas.width, canvas.height);

  // Create flag overlay
  const flagCanvas = createFlagCanvas(state.selectedFlag, canvas.width, canvas.height);

  // Calculate overlay dimensions and position
  let overlayX = 0;
  let overlayY = 0;
  let overlayWidth = canvas.width;
  let overlayHeight = canvas.height;

  switch (state.overlayPosition) {
    case 'top-left':
      overlayWidth = canvas.width / 2;
      overlayHeight = canvas.height / 2;
      break;
    case 'top-right':
      overlayX = canvas.width / 2;
      overlayWidth = canvas.width / 2;
      overlayHeight = canvas.height / 2;
      break;
    case 'bottom-left':
      overlayY = canvas.height / 2;
      overlayWidth = canvas.width / 2;
      overlayHeight = canvas.height / 2;
      break;
    case 'bottom-right':
      overlayX = canvas.width / 2;
      overlayY = canvas.height / 2;
      overlayWidth = canvas.width / 2;
      overlayHeight = canvas.height / 2;
      break;
    case 'center':
      overlayX = canvas.width / 4;
      overlayY = canvas.height / 4;
      overlayWidth = canvas.width / 2;
      overlayHeight = canvas.height / 2;
      break;
    case 'full':
    default:
      // Use full dimensions (already set)
      break;
  }

  // Set blend mode and opacity
  ctx.globalAlpha = state.overlayOpacity / 100;
  ctx.globalCompositeOperation = 'multiply';

  // Draw flag overlay
  ctx.drawImage(flagCanvas, overlayX, overlayY, overlayWidth, overlayHeight);

  // Reset context settings
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = 'source-over';
}

export function loadImageFromUrl(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function downloadCanvas(canvas: HTMLCanvasElement, filename: string, format: string = 'png'): void {
  const link = document.createElement('a');
  link.download = filename;
  link.href = canvas.toDataURL(`image/${format}`);
  link.click();
}
