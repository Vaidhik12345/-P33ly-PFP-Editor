export enum CutoutType {
    CIRCLE = "circle",
    SQUARE = "square", 
    OVERLAY = "overlay",
}

export type CanvasDrawOptions = {
    cutoutSize: number;
    resizeInwards: boolean;
    selectedColors: string[][];
    isGradient: boolean;
    isRotating: boolean;
    animationLength: number;
    isRotatingCounterClockwise: boolean;
    overlayOpacity: number;
    cutoutType: CutoutType;
    rotationOffset: number;
    flagNames?: string[];
}

export type RadioOption = {
    label: string;
    value: string;
}

export enum NoteType {
    WARN = "warn",
    INFO = "info", 
    ERROR = "error"
}

export interface PfpEditorState {
  originalImage: HTMLImageElement | null;
  selectedHat: string | null;
  selectedFrame: string | null;
  hatSettings: {
    scale: number;
    rotation: number;
    flipHorizontal: boolean;
    flipVertical: boolean;
    positionX: number;
    positionY: number;
  };
  frameSettings: {
    opacity: number;
  };
}

export interface HatOption {
  id: string;
  name: string;
  url: string;
}

export interface FrameOption {
  id: string;
  name: string;
  url: string;
}

export interface DownloadOptions {
  format: 'png' | 'jpg';
  size: 'original' | '400x400';
}